from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import redirect, render

from .models import cloths, food, ngo


# Create your views here.
def base(request):
    return render(request,'base.html')

def home(request):
    return render(request,'home.html')

####################################################
def registration(request):
    return render (request,'registration.html')
    
def registration_ngo(request,did):
    context={}
    context['donor']=int(did)
    if int(did)==1:
        if request.method=="POST":
            n=request.POST["email"]
            p=request.POST["pass"]
            cp=request.POST["cpass"]
            print(p,n,cp)
            if n=="" or p=="" or cp=="":
                context["error_message"]="Fields can not be emplty please fill the fields"
                return render(request,'registration.html',context)
            elif p!=cp:
                context["error_message"]="Password and conform password sholud be same"
                return render(request,'registration.html',context)
            else:
                u=User.objects.create(username=n,email=n)
                u.set_password(p)
                u.save()
                context["Sucess"]="Regestration Successfull now you can login"
            return redirect('/login',context)
        else:
            return render(request,'registration.html',context)
    else:
        if request.method=="POST":
            n=request.POST["email"]
            p=request.POST["pass"]
            cp=request.POST["cpass"]
            print(p,n,cp)
            if n=="" or p=="" or cp=="":
                context["error_message"]="Fields can not be emplty please fill the fields"
                return render(request,'registration.html',context)
            elif p!=cp:
                context["error_message"]="Password and conform password sholud be same"
                return render(request,'registration.html',context)
            else:
                u=User.objects.create(username=n,email=n)
                u.set_password(p)
                u.save()
                context["Sucess"]="Regestration Successfull now you can login"
            return redirect('/ngo_login',context)
        else:
            return render(request,'registration.html',context)

####################################################
def ulogin(request):
    context={}
    if request.method=="POST":
        n=request.POST["email"]
        p=request.POST["pass"]
        if n=="" or p=="":
            context["error_message"]="Fields can not be emplty please fill the fields"
            return render(request,'login.html',context)
        else:
            u=authenticate(username=n,password=p)
            if u is not None:
                login(request,u)
                return redirect('/dashboard_user')
            else:
                context['error']='Username and password not matched'
                return render(request,'login.html',context)
            return redirect('/dashboard')
    return render(request,'login.html')

def ulogout(request):
    logout(request)
    return redirect('/index')
######################################################
def nlogin(request):
    context={}
    if request.method=="POST":
        n=request.POST["email"]
        p=request.POST["pass"]
        if n=="" or p=="":
            context["error_message"]="Fields can not be emplty please fill the fields"
            return render(request,'ngo_login.html',context)
        else:
            u=authenticate(username=n,password=p)
            if u is not None:
                login(request,u)
                return redirect('/dashboard_ngo')
            else:
                context['error']='Username and password not matched'
                return render(request,'ngo_login.html',context)
            return redirect('/dashboard')
    return render(request,'ngo_login.html')

def nlogout(request):
    logout(request)
    return redirect('/index')
########################################################
def index(request):
    print(request.user.is_authenticated)
    return render(request,'index.html')
#######################################################
def dashboard_ngo(request):
    return render(request,'dashboard_ngo.html')

def donor_connected(request):
    return render(request,'donor_connected.html')
#####################################################

def dashboard_user(request):
    return render(request,'dashboard_user.html')

def dashboard_user_show(request,sid):
    context={}
    context["dashboard"]=int(sid)
    return render(request,'dashboard_user.html',context)

def dashboard_user_make(request,mid):
    context={}
    context["dashboard"]=int(mid)
    return render(request,'dashboard_user.html',context)

###############   money_donate             ###################
def money_donate(request):
    return render(request,'money_donate.html')

def money_donate_upi(request,uid):
    context={}
    context["payment"]=int(uid)
    return render(request,'money_donate.html',context)

def money_donate_card(request,cid):
    context={}
    context["payment"]=int(cid)
    return render(request,'money_donate.html',context)

def money_donate_qr(request,qid):
    context={}
    context["payment"]=int(qid)
    return render(request,'money_donate.html',context)
##################  Daily Essentials        ####################
def daily_donate(request):
    if request.method=="POST":
        s=request.POST('Shirt')
        t=request.POST('T-Shirt')
        p=request.POST('Pant')
        pp=request.POST('3/4pant')
        tt=request.POST('Top')
        k=request.POST('Kurti')
        c=request.POST('Saree')
        l=request.POST('Lageens')
        p1=request.POST('Pant1')
        print(s,p,t,'hiiii')
        obj=cloths.objects.create(Shirt=s,T_Shirt=t,Pant=p,Pant3_4=pp,Top=tt,Kurti=k,Saree=c,Lageens=l,Pant1=p1)
        obj.save()
    return render(request,'daily_donate.html')

def daily_donate_cloths(request,cid):
    context={}
    context["option"]=int(cid)
    return render(request,"daily_donate.html",context)

def daily_donate_blanket(request,bid):
    context={}
    context["option"]=int(bid)
    return render(request,"daily_donate.html",context)

def daily_donate_footware(request,fid):
    context={}
    context["option"]=int(fid)
    return render(request,"daily_donate.html",context)

def daily_donate_pillow(request,pid):
    context={}
    context["option"]=int(pid)
    return render(request,"daily_donate.html",context)
#########################################

def food_donate(request):
    if request.method=="POST":
        i=request.POST["Item"]
        p=request.POST["Place"]
        t=request.POST["Time"]
        s=request.POST["Serving"]
        e=request.POST["Expire"]
        a=request.POST["Address"]
        obj=food.objects.create(Item=i,Place=p,Time=t,Serving=s,Expire=e,Address=a)
        obj.save()
    return render(request,'food_donate.html')

def food_donate_pickup(request,aid):
    context={}
    context["pickup"]=int(aid)
    return render(request,'food_donate.html',context)
############################################

###########################################        to show the donations
def money_show(request):
    return render(request,'money_show.html')

def daily_show(request):
    return render(request,'daily_show.html')

def food_show(request):
    return render(request,'food_show.html')
#############################################
def ngos_connected(request):
    return render(request,'ngos_connected.html')

def new_ngo(request):
    return render(request,'new_ngo.html')
##############################################
def ngo_login(request):
    return render(request,'ngo_login.html')

def ngo_details(request):
    return render(request,'ngo_details.html')

def ngo_details_work(request,wid):
    context={}
    context['work']=int(wid)
    return render(request,'ngo_details.html',context)

def ngo_donation(request):
    return render(request,'ngo_donation.html')
###############################################
def contact(request):
    return render(request,'contact.html')

def admin_pannel(request):
    return render(request,'admin_pannel.html')