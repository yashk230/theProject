from django.db import models


# Create your models here.
class cloths(models.Model):
    Shirt=models.BooleanField(default=False)
    T_Shirt=models.BooleanField(default=False)
    Pant=models.BooleanField(default=False)
    Pant3_4=models.BooleanField(default=False)
    Top=models.BooleanField(default=False)
    Kurti=models.BooleanField(default=False)
    Saree=models.BooleanField(default=False)
    Lageens=models.BooleanField(default=False)
    Pant1=models.BooleanField(default=False)
    
class food(models.Model):
    Item=models.CharField(max_length=30)
    Place=models.CharField(max_length=30)
    Time=models.CharField(max_length=20)
    Serving=models.CharField(max_length=50)
    Expire=models.CharField(max_length=20)
    Address=models.CharField(max_length=50)
    
class ngo(models.Model):
    username=models.CharField(max_length=30)
    email=models.CharField(max_length=30)
    password=models.CharField(max_length=300)