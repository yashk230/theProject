"""
URL configuration for charity_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/',views.home),
    path('base/',views.base),
    path('index/',views.index),
############################################
    path('register/',views.registration),
    path('register/<did>/',views.registration_ngo),
############################################
    path('login/',views.ulogin),
    path('logout/',views.ulogout),
    path('ngo_login/',views.nlogin),
    path('ngo_logout/',views.nlogout),
    path('contact/',views.contact),
    path('admin_pannel/',views.admin_pannel),
    path('dashboard_ngo/',views.dashboard_ngo),
    path('dashboard_user/',views.dashboard_user),
    path('dashboard_user/<sid>/',views.dashboard_user_show),
    path('dashboard_user/<mid>/',views.dashboard_user_make),
####################################################################
    path('money_donate/',views.money_donate),
    path('money_donate/<uid>/',views.money_donate_upi),
    path('money_donate/<cid>/',views.money_donate_card),
    path('money_donate/<qid>/',views.money_donate_qr),
####################################################################
    path('daily_donate/',views.daily_donate),
    path('daily_donate/<cid>/',views.daily_donate_cloths),
    path('daily_donate/<bid>/',views.daily_donate_blanket),
    path('daily_donate/<fid>/',views.daily_donate_blanket),
    path('daily_donate/<pid>/',views.daily_donate_blanket),
####################################################################
    path('food_donate/',views.food_donate),
    path('food_donate/<aid>/',views.food_donate_pickup),
#####################################################################
    path('money_show/',views.money_show),
    path('daily_show/',views.daily_show),
    path('food_show/',views.food_show),
#####################################################################
    path('ngo_login/',views.ngo_login),
    path('new_ngo/',views.new_ngo),
    path('ngos_connected/',views.ngos_connected),
    path('ngo_details/',views.ngo_details),
    path('ngo_details/<wid>/',views.ngo_details_work),
    path('ngo_donations/',views.ngo_donation),
]